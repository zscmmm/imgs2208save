%% Yalmip 利用 gurobi求解器 （mac） 
% 
%% 案例1
% 
% 
% $$ max  \quad \frac{ x_{1} + x_{2}}{ (2x_1 +x_2)} \\ s.t.  \begin{cases}\quad  x_1 + x_2 \geq 2 \\ \quad x_2 - x_1 \leq 1\\ \quad x_1 \leq 1\end{cases} $$
% 
% 

%% 案例1 
% 清除工作区
clc; clear all; close all;
% 创建决策变量
x = sdpvar(1,2);
% 添加约束条件
C = [
    x(1) + x(2)  >= 2
    x(2)-x(1) <=1
    x(1)<=1
    ];
% 配置
ops = sdpsettings('verbose',1,'solver','gurobi');
% 目标函数
z = -(x(1)+2*x(2))/(2*x(1)+x(2)); % 注意这是求解最大值
% 求解
reuslt = optimize(C,z);
if reuslt.problem == 0 % problem =0 代表求解成功
    value(x)
    -value(z)   % 反转
else
    disp('求解出错');
end

%% 
% 
%% 案例2 
%% 
% * 这是yalmip官网的例子，不在给出显示表达式
%% 
% 

%%
clc; clear all; close all; yalmip('clear');
% Define variables
x = sdpvar(10,1);

% Define constraints 
Constraints = [sum(x) <= 10, x(1) == 0, 0.5 <= x(2) <= 1.5];
for i = 1 : 7
  Constraints = [Constraints, x(i) + x(i+1) <= x(i+2) + x(i+3)];
end

% Define an objective
Objective = x'*x+norm(x,1);

% Set some options for YALMIP and solver
options = sdpsettings('verbose',1,'solver','gurobi');

% Solve the problem
sol = optimize(Constraints,Objective,options);

% Analyze error flags
if sol.problem == 0
 % Extract and display value
 solution = value(x)
else
 display('Hmm, something went wrong!');
 sol.info
 yalmiperror(sol.problem)
end

%% 
% 
%% 案例3  线性混合整数规划
% 
% 
% $$\min \quad  -2 x_{1}-x_{2}-4 x_{3}-3 x_{4}-x_{5} \\ \begin{cases}2 x_{2}+x_{3}+4 
% x_{4}+2 x_{5} \leq 54 \\3 x_{1}+4 x_{2}+5 x_{3}-x_{4}-x_{5} \leq  62 \\x_{1}, 
% x_{2} \geq  0, x_{3} \geq  3.32, x_{4} \geq 0.678, x_{5} \geq  2.57\end{cases}$$
%% 
% * 上述问题,决策变量均为整数, 则最优解 [19,0,4,10,5]  最优解 -89
% * 如1,4,5 决策变量是整数, 则最优解 [19,0,3.8,11, 3]  最优解 -89.2
% * 来自 《薛定宇的最优化计算》 6-3

%% 6-3 上述问题,决策变量均为整数, 则最优解 [19,0,4,10,5]  最优解 -89
clc; clear all; close all; yalmip('clear'); 

A = [0, 2 , 1, 4, 2;
    3, 4, 5, -1,-1];
b = [54; 62];
ul = [0,0,3.32, 0.678, 2.57]';
x = intvar(5,1);
const = [A*x<=b, x>=ul];
obj = -[2,1,4,3,1] *x;
options = sdpsettings('verbose',1,'solver','gurobi');
sol = optimize(const,obj,options)

if sol.problem == 0 % problem =0 代表求解成功
    value(x)
    value(obj)
else
    disp('求解出错');
end

%% 
% 

%% 6-3 混合整数规划 如1,4,5 决策变量是整数, 则最优解 [19,0,3.8,11, 3]  最优解 -89.2
clc; clear all; close all; yalmip('clear'); 

% 设置决策变量 类型
x1 = intvar(3,1)
x2 = sdpvar(2,1)
x = [x1(1); x2; x1(2:3) ];
% 系数
A = [0, 2 , 1, 4, 2;
    3, 4, 5, -1,-1];
b = [54; 62];
ul = [0,0,3.32, 0.678, 2.57]';
const = [A*x<=b, x>=ul];
obj = -[2,1,4,3,1] *x;
sol = optimize(const,obj)

if sol.problem == 0 % problem =0 代表求解成功
    value(x)
    value(obj)
else
    disp('求解出错');
end
%% 
%% 
% 
%% 案例4 非线性混合整数规划
% 
% 
% $$\min \quad x_{1}^{2}+x_{2}^{2}+2 x_{3}^{2}+x_{4}^{2}-5 x_{1}-5 x_{2}-21 
% x_{3}+7 x_{4} \\\begin{cases}-x_{1}^{2}-x_{2}^{2}-x_{3}^{2}-x_{4}^{2}-x_{1}+x_{2}-x_{3}+x_{4}+8 
% \geq 0 \\-x_{1}^{2}-2 x_{2}^{2}-x_{3}^{2}-2 x_{4}^{2}+x_{1}+x_{4}+10 \geq  0 
% \\-2 x_{1}^{2}-x_{2}^{2}-x_{3}^{2}-2 x_{4}^{2}+x_{2}+x_{4}+5 \geq  0\end{cases}$$
% 
% 
%% 
% * 《来自薛定宇matlab 卷5最优化计算 》 6-4




clc; clear all; close all; yalmip('clear'); 
% Define variables
x = intvar(4,1);
%lb = [0,0,0,0];
% Define constraints 
Constraints = [x(1)^2 + x(2)^2 + x(3)^2 + x(4)^2 + x(1) - x(2) + x(3) - x(4) - 8 <= 0];

Constraints = [Constraints, x(1)^2 + 2*x(2)^2 + x(3)^2 + 2*x(4)^2 - x(1) - x(4) - 10 <=0];
Constraints = [Constraints, 2*x(1)^2 + x(2)^2 + x(3)^2 + 2*x(4)^2 - x(2) - x(4) - 5 <=0];
Constraints = [Constraints];
% Define an objective
Objective =  x(1)^2 + x(2)^2 + 2*x(3)^2 + x(4)^2 - 5*x(1) - 5*x(2) - 21*x(3) + 7*x(4);

% 设置求解器 
%全局最优，比较慢且使用与少数变量，使用gurobi不用担心解释器的问题啦
%options = sdpsettings('solver','bmibnb','bmibnb.upper','fmincon'); 
%options = sdpsettings('solver','bnb','bnb.solver','fmincon');
options = sdpsettings('solver','gurobi');


% Solve the problem
sol = optimize(Constraints,Objective,options);

if sol.problem == 0 % problem =0 代表求解成功
    value(x)
    value(Objective)
else
    disp('求解出错');
end
%% 
% 
% 
% 
%% 案例5  非线性混合整数规划
% 
% 
% $$Max \quad z=x_1^{2} +x_2^{2} +3x_3^{2} +4x_{4}^{2} + 2x_{5}^{2} -8x_1 -2x_2 
% -3x_3 - 2x_{5}\\\text { s.t. }\begin{cases}0<= x_i <=99 ( i =1,2, \ldots, 5)\\x_1+x_2+x_3+x_4+x_5<=400\\x_1 
% + 2x_2 + 2x_3 + x_4 +6x_5 <=800\\2x_1 +x_2 + 6x_3 <=800\\x_3 + x_4 +5x_5<=200\end{cases}$$
%% 
% * 最优解: |[ 53, 99, 99, 99 , 0]|, 对应的目标函数值  |-80199|
% * 问题来源于: <https://www.ilovematlab.cn/thread-302727-1-1.html https://www.ilovematlab.cn/thread-302727-1-1.html>


%% 混合非线性整数规划
clc, clear all;
yalmip('clear')

x=intvar(1,5);
A=[1 1 1 1 1;1 2 2 1 6;2 1 6 0 0;0 0 1 1 5];
b=[400;800;800;200];
f= - [1 1 3 4 2]*(x'.^2) + [8 2 3 1 2]*x';
F=[A*x'<=b, 0<=x<=99];
%options = sdpsettings('solver','bmibnb', 'bmibnb.uppersolver', 'fmincon');

sol = optimize(F,f);


if sol.problem == 0 % problem =0 代表求解成功
    value(x)
    value(f)
else
    disp('求解出错');
end